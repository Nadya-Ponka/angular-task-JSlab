import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DataService } from '../shared/data.service';

/* import { items } from './../shared/items';
 *//* import { CategoryShopComponent } from './../category-shop/category-shop.component';
*/
@Component({
	selector: 'app-root',
	templateUrl: './home.component.html',
	styleUrls: ['./home.component.css'],
	providers: [DataService]
})

export class HomeComponent {
	title: string = 'angular-task-JSlab';
	message = '';
	filters = [];
/* 	selectedFilters = [];
 */
	constructor(private router: Router, private dataService: DataService) { }

	ngOnInit() {
		this.dataService.getFilters().subscribe(filters => this.filters = filters);
/* 		this.selectedFilters = this.getSelectedFilters();
 */	}

	toggleShopCategory() {
		this.dataService.getFilters().subscribe(filters => this.filters = filters);
		this.message = "";

		if (this.filters.every(elem => elem.selected == false)) {
			this.message = "No category is selected. Please, make a choice";
		}
	}

	selectAllCategories() {
		this.dataService.getFilters().subscribe(filters => this.filters = filters);
		this.message = "";
	}

/* 	getSelectedFilters() {
		this.dataService.getFilters().subscribe(filters => this.filters = filters);
		return this.filters.filter(elem => elem.selected == true);
	}
 */}
