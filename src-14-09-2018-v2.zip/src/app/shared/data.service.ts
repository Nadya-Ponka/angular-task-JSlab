import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { items, filters } from '../shared/data';

@Injectable()
export class DataService {

	private dataSource = new BehaviorSubject<any>(filters);
	filters = this.dataSource.asObservable();

	items = items;
	constructor() {}

	updatedDataSelection(filters) {
		this.dataSource.next(this.filters);
	}

	public getData(): any {
		return this.items;
	}

	public getFilters(): any {
		return this.filters;
	}

	toggle(obj: { category: string, selected: boolean }) {
		obj.selected = !obj.selected;
	}

	selectAllFilters(arr) {
		arr.forEach(elem => elem.selected = true);
	}
}
