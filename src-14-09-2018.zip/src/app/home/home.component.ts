import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DataService } from '../shared/data.service';

/* import { items } from './../shared/items';
 *//* import { CategoryShopComponent } from './../category-shop/category-shop.component';
*/
@Component({
	selector: 'app-root',
	templateUrl: './home.component.html',
	styleUrls: ['./home.component.css'],
	providers: [DataService]
})

export class HomeComponent  {

	title: string = 'angular-task-JSlab';
	message = '';
	filters = [];

	/* 	items: Array<any>;
	 */


	constructor(private router: Router, public dataService: DataService) { }

	 

	ngOnInit() {
		console.log('initialisation');
		this.filters = this.dataService.getFilters();

	}

	toggleShopCategory() {
		this.filters = this.dataService.getFilters();
		this.message = "";

		if (this.filters.every(elem => elem.selected == false)) {
			this.message = "No category is selected. Please, make a choice";
		}
	}

	selectAllCategories() {
		this.filters = this.dataService.getFilters();
		this.message = "";
		console.log("We are here!");
		console.dir(this.filters);

	}
}
