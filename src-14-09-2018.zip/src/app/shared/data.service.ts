import { Injectable } from '@angular/core';

import { items } from '../shared/items';

@Injectable()
export class DataService {

	items = items;

	public filters = [
		{
			category: 'men',
			selected: true
		},
		{
			category: 'women',
			selected: true
		},
		{
			category: 'children',
			selected: false
		},
	];

	getData(): any {
		return this.items;
	}

	getFilters(): any {
		return this.filters;
	}
	setFilters(arr) {
		this.filters = arr;
		console.log(this.filters);

	}

	toggle(obj: { category: string, selected: boolean }) {
		for (let i = 0; i < this.filters.length; i++) {
			if (this.filters[i].category == obj.category) { this.filters[i].selected = !this.filters[i].selected }
		}
		obj.selected = !obj.selected;
		console.log("New data: ");
		console.log(this.filters);
	}

	selectAllFilters(arr) {
		/* for (let i = 0; i < this.filters.length; i++) {
			this.filters[i].selected = true;
		} */
		arr.forEach(elem => elem.selected = true);
		console.log("Another New data: ");
		console.log(arr);
		this.filters.forEach(elem => elem.selected = true);
		console.log("Another Filters data: ");
		console.log(this.filters);

	}

		//this.filters.filter(item => item.selected).map(item => item.category )
/*     addData(name: string, price: number){
         
        this.data.push(new Phone(name, price));
    }
 */}