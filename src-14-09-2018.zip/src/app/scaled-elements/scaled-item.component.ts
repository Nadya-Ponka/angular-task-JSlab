import { Component, Input, OnChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

import { DataService } from '../shared/data.service';

/* import { items } from './../shared/items';
 */
@Component({
	selector: 'scaled-item',
	templateUrl: './scaled-item.component.html',
	styleUrls: ['./scaled-item.component.css'],
	providers: [DataService]
})
export class ScaledItemComponent {
public filters = this.dataService.getFilters();

	item = {};

	id: number;
	constructor(private activateRoute: ActivatedRoute, private router: Router, private location: Location, public dataService: DataService) {
		this.id = activateRoute.snapshot.params['id'];
		let temp = this.dataService.getData().filter(elem => elem.id == this.id)
		this.item = temp[0];
		let arr = this.dataService.getFilters();
		console.log('filters');

console.log(arr);
	}
	

	 backCatalogue(): void {
		console.log('here');
		console.log(this.filters);
 console.log(this.dataService.getFilters());
		this.location.back();

	}
}