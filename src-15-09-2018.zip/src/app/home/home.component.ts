import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

import { DataService } from '../shared/data.service';

/* import { items } from './../shared/items';
 *//* import { CategoryShopComponent } from './../category-shop/category-shop.component';
*/
@Component({
	selector: 'app-root',
	templateUrl: './home.component.html',
	styleUrls: ['./home.component.css'],
	providers: [DataService]
})

export class HomeComponent {
	@Input() sort;

	title: string = 'angular-task-JSlab';
	message = '';
	data = [];
	filters = [];
	items = [];
	public carouselTileItems: Array<any> = [];

/* 	selectedFilters = [];
 */
	constructor(private router: Router, private dataService: DataService) { }

	ngOnInit() {
		this.dataService.getFilters().subscribe(data => this.filters = data[1]);
		this.dataService.getData().subscribe(data => this.items = data[0]);
		this.carouselTileItems[0] = this.items.filter(elem => (elem.whose == 'men'));
		this.carouselTileItems[1] = this.items.filter(elem => (elem.whose == 'women'));
		this.carouselTileItems[2] = this.items.filter(elem => (elem.whose == 'children'));
		console.log(this.carouselTileItems);
/* 		this.dataService.getData().subscribe(items => this.items = items);
 */
/* 		this.selectedFilters = this.getSelectedFilters();
 */	}

	toggleShopCategory() {
		this.dataService.getFilters().subscribe(data => this.filters = data[1]);
		this.message = "";

		if (this.filters.every(elem => elem.selected == false)) {
			this.message = "No category is selected. Please, make a choice";
		}
	}

	selectAllCategories() {
		this.dataService.getFilters().subscribe(data => this.filters = data[1]);
		this.message = "";
	}

	sortItemsByField($event) {
		this.dataService.sortByField($event.field, this.items);
		this.dataService.getData().subscribe(data => this.items = data[0]);
		this.carouselTileItems[0] = this.items.filter(elem => (elem.whose == 'men'));
		this.carouselTileItems[1] = this.items.filter(elem => (elem.whose == 'women'));
		this.carouselTileItems[2] = this.items.filter(elem => (elem.whose == 'children'));
	}
/* 	getSelectedFilters() {
		this.dataService.getFilters().subscribe(filters => this.filters = filters);
		return this.filters.filter(elem => elem.selected == true);
	}
 */}
