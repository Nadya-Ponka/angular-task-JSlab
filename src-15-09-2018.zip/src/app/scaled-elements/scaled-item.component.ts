import { Component, Input, OnChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { Subscription } from 'rxjs';

import { DataService } from '../shared/data.service';

@Component({
	selector: 'scaled-item',
	templateUrl: './scaled-item.component.html',
	styleUrls: ['./scaled-item.component.css'],
})
export class ScaledItemComponent {
	private routeSubscription: Subscription;
	private querySubscription: Subscription;

	private price: number;
	private colors: string[];
	private size: string[];
	private image: string;
	private whose: string;
	private id: number;

	constructor(private activateRoute: ActivatedRoute, private router: Router, private location: Location) {
		this.id = activateRoute.snapshot.params['id'];
		this.querySubscription = activateRoute.queryParams.subscribe(
			            (queryParam: any) => {
			                this.price = queryParam['price'];
			                this.colors = queryParam['colors'];
											this.size = queryParam['size'];
											this.image = queryParam['image'];
											this.whose = queryParam['whose'];
			            }
			        );
	}

	backCatalogue(): void {
		this.location.back();
	}
}
