import { Component } from '@angular/core';
import { NguCarousel } from '@ngu/carousel';

import { items } from './shared/data';
import { DataService } from './shared/data.service';

//import { CategoryShopComponent } from './category-shop/category-shop.component';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css'],
	providers: [DataService]

})
export class AppComponent {
	title: string = 'angular-task-JSlab';

}
