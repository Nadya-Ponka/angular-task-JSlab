import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { sortBy } from '../shared/data';

@Component({
	selector: 'sorts-element',
	templateUrl: './sorting.component.html',
	styleUrls: ['./sorting.component.css']
})
export class SortingComponent implements OnInit {
	@Output() sortItemsByField = new EventEmitter();
/* 	@Output() sort;
 */

	private sortBy = sortBy;

	constructor() {}

	ngOnInit() {}

	onSortItemsByField(field) {
/* 		this.sort = field;
 */		this.sortItemsByField.emit({ field: field });
	}
}
