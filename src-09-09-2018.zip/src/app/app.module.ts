import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatSelectModule } from '@angular/material';
import { NguCarouselModule } from '@ngu/carousel';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { NotFoundComponent } from './not-found.component';
import { ScaledItemComponent } from './scaled-elements/scaled-item.component';

//import { CategoryShopComponent } from './category-shop/category-shop.component';

const appRoutes: Routes = [
	{ path: '', component: AppComponent }, // может быть не надо этот маршрут
	{ path: 'scaled', component: ScaledItemComponent },
	{ path: '**', component: NotFoundComponent }
];

@NgModule({
	declarations: [
		AppComponent,
		NotFoundComponent,
		ScaledItemComponent
		//	CategoryShopComponent
	],
	imports: [
		BrowserModule,
		MatSelectModule,
		NguCarouselModule,
		RouterModule.forRoot(appRoutes),
	],
	providers: [],
	bootstrap: [AppComponent]
})
export class AppModule { }
