import { Component, OnInit } from '@angular/core';
import { NguCarousel } from '@ngu/carousel';

import { items } from './shared/items'

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

	title: string = 'angular-task-JSlab';
	message = '';
	filters = [
		{
			category: 'men',
			selected: true
		},
		{
			category: 'women',
			selected: true
		},
		{
			category: 'children',
			selected: true
		},
	];

	sortBy = ['price', 'name'];

	items: Array<any>;

	men: Array<any>;
	women: Array<any>;
	children: Array<any>;

	public carouselTileItems: Array<any> = [];
	public carouselTile: NguCarousel;

	constructor() { }

	ngOnInit() {
		this.items = items;
		this.carouselTileItems[0] = this.items.filter(elem => (elem.whose == 'men'));
		this.carouselTileItems[1] = this.items.filter(elem => (elem.whose == 'women'));
		this.carouselTileItems[2] = this.items.filter(elem => (elem.whose == 'children'));

		this.carouselTile = {
			grid: { xs: 2, sm: 3, md: 3, lg: 3, all: 0 },
			speed: 600,
			interval: 3000,
			point: {
				visible: true,
				pointStyles: `
          .ngucarouselPoint {
            list-style-type: none;
            text-align: center;
            padding: 12px;
            margin: 0;
            white-space: nowrap;
            overflow: auto;
            box-sizing: border-box;
          }
          .ngucarouselPoint li {
            display: inline-block;
            border-radius: 50%;
            border: 2px solid rgba(0, 0, 0, 0.55);
            padding: 4px;
            margin: 0 3px;
            transition-timing-function: cubic-bezier(.17, .67, .83, .67);
            transition: .4s;
          }
          .ngucarouselPoint li.active {
              background: #6b6b6b;
              transform: scale(1.2);
          }
        `
			},
			load: 4,
			touch: true
		};

		//this.carouselTileLoad();

		// this.sort(this.column);
	}

	/* 	public carouselTileLoad() {
			const len = this.carouselTileItems.length;
			let selectedArray = this.filters.filter(x => (x.selected == true));
	
			if (selectedArray.length) {
				for (let j = 0; j < selectedArray.length; j++) {
					if (len <= 2) {
						for (let i = len; i < len + this.items.length; i++) {
							if (this.items[i].whose == selectedArray[j].category) {
								this.carouselTileItems.push(
									this.items[i]
								);
								console.log(this.carouselTileItems);
							}
						}
					}
				}
			} else {
				if (len <= 3) {
					for (let i = len; i < len + this.items.length; i++) {
						this.carouselTileItems.push(
							this.items[i]
						);
					}
				}
			}
	
	
		} */

	toggle(obj: { category: string, selected: boolean }) {
	/* 	if (obj.category == "Select all products") {
			for (var i = 0; i < this.filters.length - 1; i++) {
				this.filters[i].selected = !obj.selected;
			}
			obj.selected = !obj.selected;
		} else */ {
/* 			if (this.filters[this.filters.length - 1].selected == true) {
				this.filters[this.filters.length - 1].selected = false;
			}
 */			obj.selected = !obj.selected;
				 this.message = "";

 				if(this.filters.every(elem => elem.selected == false)) {
					 this.message = "No category is selected. Please, make a choice";
				 }

		
/* 		}
 */	}

	}
	selectAllFilters() {
		/* for (let i = 0; i < this.filters.length; i++) {
			this.filters[i].selected = true;
		} */
		this.filters.map(elem => elem.selected = true);
		this.message = "";

	}
	sortItemsByField(field) {
		function sorted(a, b) {
			if (field == 'price') {
				if (a[field] < b[field])
					return -1;
				if (a[field] > b[field])
					return 1;
				return 0;
			}
			else {
				if (a[field].toString().toUpperCase() < b[field].toString().toUpperCase())
					return -1;
				if (a[field].toString().toUpperCase() > b[field].toString().toUpperCase())
					return 1;
				return 0;
			}
		}
		this.items.sort(sorted);
		for (let i = 0; i < this.carouselTileItems.length; i++) {
			this.carouselTileItems[i].sort(sorted);
		}
	}

	public myfunc(event: Event) {
		// carouselLoad will trigger this funnction when your load value reaches
		// it is helps to load the data by parts to increase the performance of the app
		// must use feature to all carousel
	}

}
