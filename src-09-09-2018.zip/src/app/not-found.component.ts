import { Component} from '@angular/core';
  
@Component({
    selector: 'not-found-app',
    template: `<h3>Page not found</h3>`
})
export class NotFoundComponent { }