import { Component} from '@angular/core';
  
@Component({
    selector: 'scaled-item',
		templateUrl: './scaled-item.component.html',
		styleUrls: ['./scaled-item.component.css']
	})
export class ScaledItemComponent { }