import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatSelectModule } from '@angular/material';
import { NguCarouselModule } from '@ngu/carousel';

import { AppComponent } from './app.component';
//import { CategoryShopComponent } from './category-shop/category-shop.component';

@NgModule({
  declarations: [
		AppComponent
	//	CategoryShopComponent
  ],
  imports: [
		BrowserModule,
		MatSelectModule,
		NguCarouselModule
	],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
