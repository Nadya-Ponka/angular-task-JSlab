import { Component } from '@angular/core';

import { items } from '../shared/items';

@Component({
  selector: 'category-shop',
  templateUrl: './category-shop.component.html',
  styleUrls: ['./category-shop.component.css']
})

export class CategoryShopComponent {
	items = items;
}