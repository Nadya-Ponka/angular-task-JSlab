import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

import { items } from './../shared/items';

@Component({
	selector: 'scaled-item',
	templateUrl: './scaled-item.component.html',
	styleUrls: ['./scaled-item.component.css']
})
export class ScaledItemComponent {

	item = {};

	id: number;
	constructor(private activateRoute: ActivatedRoute, private router: Router, private location: Location) {
		this.id = activateRoute.snapshot.params['id'];
		let temp = items.filter(elem => elem.id == this.id)
		this.item = temp[0];
	}
	
	public backCatalogue(): void {
		this.location.back();
	}
}